let ballCount = 0;
var wicketcount = 0;
let extracount = 0;
let runratecalculater = 0;
let run_rate =0;
let over_rate = 0;
let overs =0;
let currentOverBalls = 0.0;
let targermarks = 0;


document.getElementById("demo1").innerHTML = "Muditha";


function wickets(num){
    
    if(num == 1){
        wicketcount++;
        ballCount++;
        updateOvers();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<font color = red>W</font>";
        
    }if(num == 2){
        wicketcount++;
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<font color = red>W</font>";
    }if(num == 3){
        wicketcount++;
        ballCount++;
        updateOvers();
        updateRuns(-29);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "W[+1]";
    }if(num == 4){
        wicketcount++;
        ballCount++;
        updateOvers();
        updateRuns(-30);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "W[+2]";
    }
    if(num == 5){
        wicketcount++;
        ballCount++;
        updateOvers();
        updateRuns(-31);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "W[+3]";
    }
    
    const output = document.getElementById('11');
    output.value = wicketcount;

    // update the ball count
    
}


function updateRuns(run) { 
    
    const output = document.getElementById('runs');
    
    if(run == 0 || run == 1 || run == 2 || run == 3 || run == 4 || run == 5 || run == 6){
        // increment ball count
        ballCount++;
        updateOvers();
        //alert("hello");
        if(run == 0){
            document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "*"; // this over
        }else{
            document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + run; // this over
        }
    }if(run == -1 ){
        //byes
        run=0;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(0);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B";
    }if(run == -2 ){
        //byes
        run=1;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[1]";
    }if(run == -3 ){
        //byes
        run=2;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(2);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[2]";
    }if(run == -4 ){
        //byes
        run=3;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(3);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[3]";
    }if(run == -5 ){
        //byes
        run=4;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(4);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[4]";
    }if(run == -6 ){
        //byes
        run=5;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(5);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[5]";
    }if(run == -7 ){
        //byes
        run=6;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(6);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "B[6]";
    }if(run == -8 ){  //byes 7-----------------------------------------------------------------------------
        //byes
        run=7;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(7);
    }if(run == -9 ){
        //byes
        run=0;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(0);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "LB";
    }if(run == -10 ){
        //byes
        run=1;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "LB[1]";
    }if(run == -11 ){
        //byes
        run=2;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(2);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "LB[2]";
    }if(run == -12 ){ // leg byes 3---------------------------------------------------------------------------------------
        //byes
        run=3;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(3);
    }if(run == -13 ){
        //byes
        run=4;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(4);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "LB[4]";
    }if(run == -14 ){ //leg byes 5--------------------------------------------------------------------------------------
        //byes
        run=5;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(5);
    }if(run == -15 ){ //leg byes 6--------------------------------------------------------------------------------------
        //byes
        run=6;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(6);
    }if(run == -16 ){ //leg byes 7--------------------------------------------------------------------------------------
        //byes
        run=7;
        // increment ball count
        ballCount++;
        updateOvers();
        extrarun(7);
    }if(run == -17 ){
        run=1;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB</mark>";
    }if(run == -18 ){
        run=2;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB[1]</mark>";
    }if(run == -19 ){
        run=3;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB[2]</mark>";
    }if(run == -20 ){
        run=4;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB[3]</mark>";
    }if(run == -21 ){
        run=5;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB[4]</mark>";
    }if(run == -22 ){
        run=7;
        extrarun(1);
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "<mark>NB[6]</mark>";
    }if(run == -24 ){
        run=1;
        extrarun(1);
        runrate();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "WD";
    }if(run == -25 ){
        run=2;
        extrarun(2);
        runrate();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "WD[1]";
    }if(run == -26 ){
        run=3;
        extrarun(3);
        runrate();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "WD[2]";
    }if(run == -27 ){
        run=4;
        extrarun(4);
        runrate();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "WD[3]";
    }if(run == -28 ){
        run=5;
        extrarun(5);
        runrate();
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "WD[4]";
    }if(run == -29){
        run = 1;
    }
    if(run == -30){
        run = 2;
    }if(run == -31){
        run = 3;
    }if(run == -32){
        run = 0;
        alert(run);
    }

    let current = +output.value ;
    output.value = current + +run; 
    run_rate= output.value;
}
 var x =0;
function updateOvers() {
    const oversOutput = document.getElementById('overs');
    


    overs = Math.floor(ballCount / 6);
    currentOverBalls = ballCount % 6;

    oversOutput.value = `${overs}.${currentOverBalls}`;
    over_rate = oversOutput.value;
    runrate();
    
    x++;

    if(x==7 ){
        document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML + "}{";
        x=1;
    }
}
function extrarun(run){
    const outputss = document.getElementById('extramarks');
    extracount++;
    let extra = +outputss.value ;
    outputss.value = extra + +run;
}

function runrate(){
    const outputrate = document.getElementById('runratetext');    
    runratecalculater = ( run_rate / ((( 1 / 6 )* currentOverBalls) + overs )).toFixed(2);
    outputrate.value = runratecalculater;
    
    //alert(run_rate);
    // if(currentOverBalls == 1 || overs == 0){
    //     runratecalculater = (run_rate /((1/6)*currentOverBalls));
    //     outputrate.value = runratecalculater;
    // }
}


function finish() {
    const targetrun = document.getElementById("target");
    const optargetrun = document.getElementById("optarget");
    
    let targetrunadd = +run_rate + 1;
    targetrun.value = targetrunadd;
    optargetrun.value = targetrunadd;

    targermarks = targetrun.value;
 }

 //Disable Button
 const btn = document.getElementById("disableid");
 const btn1 = document.getElementById("disableid1");
 const btn2 = document.getElementById("disableid2");
 const btn3 = document.getElementById("disableid3");
 const btn4 = document.getElementById("disableid4");
 const btn5 = document.getElementById("disableid5");
 const btn6 = document.getElementById("disableid6");
 const btn7 = document.getElementById("disableid7");
 const btn8 = document.getElementById("disableid8");
 const btn9 = document.getElementById("disableid9");
 const btn10 = document.getElementById("disableid10");
 const btn11 = document.getElementById("disableid11");
 const btn12 = document.getElementById("disableid12");
 const btn13 = document.getElementById("disableid13");
 const btn14 = document.getElementById("disableid14");
 const btn15 = document.getElementById("disableid15");
 const btn16 = document.getElementById("disableid16");
 const btn17 = document.getElementById("disableid17");
 const btn18 = document.getElementById("disableid18");
 const btn19 = document.getElementById("disableid19");
 const btn20 = document.getElementById("disableid20");
 const btn21 = document.getElementById("disableid21");
 const btn22 = document.getElementById("disableid22");
 const btn23 = document.getElementById("disableid23");
 const btn24 = document.getElementById("disableid24");
 const btn25 = document.getElementById("disableid25");
 const btn26 = document.getElementById("disableid26");
 const btn27 = document.getElementById("disableid27");
 const btn28 = document.getElementById("disableid28");
 const btn29 = document.getElementById("disableid29");
 const btn30 = document.getElementById("disableid30");
 const btn31 = document.getElementById("disableid31");
 const btn32 = document.getElementById("disableid32");
 const btn33 = document.getElementById("disableid33");
 const btn34 = document.getElementById("disableid34");
 const btn35 = document.getElementById("disableid35");
 const btn36 = document.getElementById("disableid36");
 const btn37 = document.getElementById("disableid37");
 const btn38 = document.getElementById("disableid38");
 const btn39 = document.getElementById("disableid39");
 const btn40 = document.getElementById("disableid40");
 const btn41 = document.getElementById("disableid41");
 const btn42 = document.getElementById("disableid42");

  //Enable Button
  const btn50 = document.getElementById("disableid50");
  const btn51 = document.getElementById("disableid51");
  const btn52 = document.getElementById("disableid52");
  const btn53 = document.getElementById("disableid53");
  const btn54 = document.getElementById("disableid54");
  const btn55 = document.getElementById("disableid55");
  const btn56 = document.getElementById("disableid56");
  const btn57 = document.getElementById("disableid57");
  const btn58 = document.getElementById("disableid58");
  const btn59 = document.getElementById("disableid59");
  const btn60 = document.getElementById("disableid60");
  const btn61 = document.getElementById("disableid61");
  const btn62 = document.getElementById("disableid62");
  const btn63 = document.getElementById("disableid63");
  const btn64 = document.getElementById("disableid64");
  const btn65 = document.getElementById("disableid65");
  const btn66 = document.getElementById("disableid66");
  const btn67 = document.getElementById("disableid67");
  const btn68 = document.getElementById("disableid68");
  const btn69 = document.getElementById("disableid69");
  const btn70 = document.getElementById("disableid70");
  const btn71 = document.getElementById("disableid71");
  const btn72 = document.getElementById("disableid72");
  const btn73 = document.getElementById("disableid73");
  const btn74 = document.getElementById("disableid74");
  const btn75 = document.getElementById("disableid75");
  const btn76 = document.getElementById("disableid76");
  const btn77 = document.getElementById("disableid77");
  const btn78 = document.getElementById("disableid78");
  const btn79 = document.getElementById("disableid79");
  const btn80 = document.getElementById("disableid80");
  const btn81 = document.getElementById("disableid81");
  const btn82 = document.getElementById("disableid82");
  const btn83 = document.getElementById("disableid83");
  const btn84 = document.getElementById("disableid84");
  const btn85 = document.getElementById("disableid85");
  const btn86 = document.getElementById("disableid86");
  const btn87 = document.getElementById("disableid87");
  const btn88 = document.getElementById("disableid88");
  const btn89 = document.getElementById("disableid89");
  const btn90 = document.getElementById("disableid90");
  const btn91 = document.getElementById("disableid91");
  const btn92 = document.getElementById("disableid92");

 const hidbtn = document.getElementById("resers");
 hidbtn.addEventListener("click", () =>{
     btn.disabled = true;
     btn1.disabled = true;
     btn2.disabled = true;
     btn3.disabled = true;
     btn4.disabled = true;
     btn5.disabled = true;
     btn6.disabled = true;
     btn7.disabled = true;
     btn8.disabled = true;
     btn9.disabled = true;
     btn10.disabled = true;
     btn11.disabled = true;
     btn12.disabled = true;
     btn13.disabled = true;
     btn14.disabled = true;
     btn15.disabled = true;
     btn16.disabled = true;
     btn17.disabled = true;
     btn18.disabled = true;
     btn19.disabled = true;
     btn20.disabled = true;
     btn21.disabled = true;
     btn22.disabled = true;
     btn23.disabled = true;
     btn24.disabled = true;
     btn25.disabled = true;
     btn26.disabled = true;
     btn26.disabled = true;
     btn27.disabled = true;
     btn28.disabled = true;
     btn29.disabled = true;
     btn30.disabled = true;
     btn31.disabled = true;
     btn32.disabled = true;
     btn33.disabled = true;
     btn34.disabled = true;
     btn35.disabled = true;
     btn36.disabled = true;
     btn37.disabled = true;
     btn38.disabled = true;
     btn39.disabled = true;
     btn40.disabled = true;
     btn41.disabled = true;
     btn42.disabled = true;

     btn50.disabled = false;
     btn51.disabled = false;
     btn52.disabled = false;
     btn53.disabled = false;
     btn54.disabled = false;
     btn55.disabled = false;
     btn56.disabled = false;
     btn57.disabled = false;
     btn58.disabled = false;
     btn59.disabled = false;
     btn60.disabled = false;
     btn61.disabled = false;
     btn62.disabled = false;
     btn63.disabled = false;
     btn64.disabled = false;
     btn65.disabled = false;
     btn66.disabled = false;
     btn67.disabled = false;
     btn68.disabled = false;
     btn69.disabled = false;
     btn70.disabled = false;
     btn71.disabled = false;
     btn72.disabled = false;
     btn73.disabled = false;
     btn74.disabled = false;
     btn75.disabled = false;
     btn76.disabled = false;
     btn76.disabled = false;
     btn77.disabled = false;
     btn78.disabled = false;
     btn79.disabled = false;
     btn80.disabled = false;
     btn81.disabled = false;
     btn82.disabled = false;
     btn83.disabled = false;
     btn84.disabled = false;
     btn85.disabled = false;
     btn86.disabled = false;
     btn87.disabled = false;
     btn88.disabled = false;
     btn89.disabled = false;
     btn90.disabled = false;
     btn91.disabled = false;
     btn92.disabled = false;
 });


 // opasit Score Board


let opballCount = 0;
var opwicketcount = 0;
let opextracount = 0;
let oprunratecalculater = 0;
let oprun_rate =0;
let opover_rate = 0;
let opovers =0;
let opcurrentOverBalls = 0.0;


// document.getElementById("demo1").innerHTML = "Muditha";


 function opwickets(num){
    
    if(num == 1){
        opwicketcount++;
        opballCount++;
        opupdateOvers();
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<font color = red>W</font>";
        
    }if(num == 2){
        opwicketcount++;
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<font color = red>W</font>";
    }if(num == 3){
        opwicketcount++;
        opballCount++;
        opupdateOvers();
        opupdateRuns(-29);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "W[+1]";
    }if(num == 4){
        opwicketcount++;
        opballCount++;
        opupdateOvers();
        opupdateRuns(-30);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "W[+2]";
    }if(num == 5){
        opwicketcount++;
        opballCount++;
        opupdateOvers();
        opupdateRuns(-31);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "W[+3]";
    }
    
    const opoutput = document.getElementById('opwicket');
    opoutput.value = opwicketcount;

//     // update the ball count
    
 }
const newtarget = 0;

function opupdateRuns(run) { 
    
     const output = document.getElementById('opruns');
    
    if(run == 0 || run == 1 || run == 2 || run == 3 || run == 4 || run == 5 || run == 6){
        // increment ball count
        opballCount++;
        opupdateOvers();
        newtargetcount(run);
        //alert("hello");
        if(run == 0){
            document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "*"; // this over
        }else{
            document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + run; // this over
        }
    }if(run == -1 ){
        //byes
        run=0;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(0);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B";
    }if(run == -2 ){
        //byes
        run=1;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[1]";
    }if(run == -3 ){
        //byes
        run=2;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(2);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[2]";
    }if(run == -4 ){
        //byes
        run=3;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(3);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[3]";
    }if(run == -5 ){
        //byes
        run=4;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(4);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[4]";
    }if(run == -6 ){
        //byes
        run=5;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(5);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[5]";
    }if(run == -7 ){
        //byes
        run=6;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(6);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "B[6]";
    }if(run == -8 ){
        //byes
        run=7;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(7);
        newtargetcount(run);
    }if(run == -9 ){
        //byes
        run=0;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(0);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "LB";
    }if(run == -10 ){
        //byes
        run=1;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "LB[1]";
    }if(run == -11 ){
        //byes
        run=2;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(2);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "LB[2]";
    }if(run == -12 ){
        //byes
        run=3;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(3);
        newtargetcount(run);
    }if(run == -13 ){
        //byes
        run=4;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(4);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "LB[4]";
    }if(run == -14 ){
        //byes
        run=5;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(5);
        newtargetcount(run);
    }if(run == -15 ){
        //byes
        run=6;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(6);
        newtargetcount(run);
    }if(run == -16 ){
        //byes
        run=7;
        // increment ball count
        opballCount++;
        opupdateOvers();
        opextrarun(7);
        newtargetcount(run);
    }if(run == -17 ){
        run=1;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB</mark>";
    }if(run == -18 ){
        run=2;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB[1]</mark>";
    }if(run == -19 ){
        run=3;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB[2]</mark>";
    }if(run == -20 ){
        run=4;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB[3]</mark>";
    }if(run == -21 ){
        run=5;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB[4]</mark>";
    }if(run == -22 ){
        run=7;
        opextrarun(1);
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "<mark>NB[6]</mark>";
    }if(run == -24 ){
        run=1;
        opextrarun(1);
        oprunrate();
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "WD";
    }if(run == -25 ){
        run=2;
        opextrarun(2);
        oprunrate();
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "WD[1]";
    }if(run == -26 ){
        run=3;
        opextrarun(3);
        oprunrate();
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "WD[2]";
    }if(run == -27 ){
        run=4;
        opextrarun(4);
        oprunrate();
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "WD[3]";
    }if(run == -28 ){
        run=5;
        opextrarun(5);
        oprunrate();
        newtargetcount(run);
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "WD[4]";
    }if(run == -29){
        run = 1;
    }
    if(run == -30){
        run = 2;
    }if(run == -31){
        run = 3;
    }if(run == -32){
        run = 0;
        //alert(run);
    }

    let current = +output.value ;
    output.value = current + +run; 
    oprun_rate= output.value;
}
 var opx =0;
function opupdateOvers() {
    const oversOutput = document.getElementById('opovers');
    


    opovers = Math.floor(opballCount / 6);
    opcurrentOverBalls = opballCount % 6;

    oversOutput.value = `${opovers}.${opcurrentOverBalls}`;
    opover_rate = oversOutput.value;
    oprunrate();
    
    opx++;

    if(opx==7 ){
        document.getElementById("opdemo").innerHTML = document.getElementById("opdemo").innerHTML + "}{";
        opx=1;
    }
 }

function opextrarun(run){
    const outputsss = document.getElementById('opextramarks');
    opextracount++;
    let opextra = +outputsss.value ;
    outputsss.value = opextra + +run;
}

function newtargetcount(run){
    const tagetOutput = document.getElementById('optarget');
    const realtarget = tagetOutput.value
    tagetOutput.value = realtarget - +run;
    
    if (tagetOutput.value == 0 || tagetOutput.value == -1 || tagetOutput.value == -2 || tagetOutput.value == -3 || tagetOutput.value == -4 || tagetOutput.value == -5 || tagetOutput.value == -6 ){
        alert("End of the Match..!");
        tagetOutput.value = 0;
    }
}

function oprunrate(){
    const opoutputrate = document.getElementById('oprunratetext');    
    oprunratecalculater = ( oprun_rate / ((( 1 / 6 )* opcurrentOverBalls) + opovers )).toFixed(2);
    opoutputrate.value = oprunratecalculater;
}
function opfinish() {
    var team01 = document.getElementById("runs");
    var team02 = document.getElementById("opruns");

    var te01 = team01.value;
    var te02 = team02.value;

    if (te01 < te02){
        alert("B");
    }if(te02 < te01 ){
        alert("A");
    }
 }
 const ophidbtn = document.getElementById("opresers");
 ophidbtn.addEventListener("click", () =>{
     btn50.disabled = true;
     btn51.disabled = true;
     btn52.disabled = true;
     btn53.disabled = true;
     btn54.disabled = true;
     btn55.disabled = true;
     btn56.disabled = true;
     btn57.disabled = true;
     btn58.disabled = true;
     btn59.disabled = true;
     btn60.disabled = true;
     btn61.disabled = true;
     btn62.disabled = true;
     btn63.disabled = true;
     btn64.disabled = true;
     btn65.disabled = true;
     btn66.disabled = true;
     btn67.disabled = true;
     btn68.disabled = true;
     btn69.disabled = true;
     btn70.disabled = true;
     btn71.disabled = true;
     btn72.disabled = true;
     btn73.disabled = true;
     btn74.disabled = true;
     btn75.disabled = true;
     btn76.disabled = true;
     btn76.disabled = true;
     btn77.disabled = true;
     btn78.disabled = true;
     btn79.disabled = true;
     btn80.disabled = true;
     btn81.disabled = true;
     btn82.disabled = true;
     btn83.disabled = true;
     btn84.disabled = true;
     btn85.disabled = true;
     btn86.disabled = true;
     btn87.disabled = true;
     btn88.disabled = true;
     btn89.disabled = true;
     btn90.disabled = true;
     btn91.disabled = true;
     btn92.disabled = true;
 });